import "./App.css";
import Index from "./screen/Index";
import React from "react";

function App() {
  return <Index />;
}

export default App;
