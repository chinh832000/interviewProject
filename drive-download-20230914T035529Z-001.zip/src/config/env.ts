export default {
  BASE_URL: "https://dummyjson.com",
};
